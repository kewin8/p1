package com.javatpoint.controllers;   
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;   
import com.javatpoint.beans.log;  
import com.javatpoint.dao.logDao;  
import java.time.LocalDateTime;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller  
public class HomeController {  
    @Autowired  
    logDao dao;//will inject dao from xml file  
      
    @RequestMapping(value="/register",method = RequestMethod.POST)  
    public String save(@ModelAttribute("name") @Valid log regist, 
      BindingResult bindingResult){ 
        if (bindingResult.hasErrors()) {
         return "index";
      }
        dao.save(regist);  
        return "redirect:/viewemp";//will redirect to viewemp request mapping  
    }  
    /* It provides list of employees in model object   
    @RequestMapping("/viewemp")  
    public String viewemp(Model m){  
        List<log> list=dao.getEmployees();  
        m.addAttribute("list",list);
        return "viewemp";  
    }  
    /* It displays object data into form for the given id.  
     * The @PathVariable puts URL data into variable.*/  
    @RequestMapping(value="/editemp/{id}")  
    public String edit(@PathVariable int id, Model m){  
        log emp=dao.getEmpById(id);  
        m.addAttribute("command",emp);
        return "empeditform";  
    }  
    /* It updates model object.  
    @RequestMapping(value="/editsave",method = RequestMethod.POST)  
    public String editsave(@ModelAttribute("emp") log emp){  
        dao.update(emp);  
        return "redirect:/viewemp";  
    }  
    /* It deletes record for the given id in URL and redirects to /viewemp */  
    @RequestMapping(value="/deleteemp/{id}",method = RequestMethod.GET)  
    public String delete(@PathVariable int id){  
        dao.delete(id);  
        return "redirect:/viewemp";  
    }
    @GetMapping("/report")
    public String handleForexRequest(Model model) {
        model.addAttribute("report", getReport());
        return "reportView";
    }
     public Report getReport() {
        //dummy report
        Report report = new Report();
        report.setName("My Report");
        report.setContent("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. "
                + "Aenean commodo ligula eget dolor. Aenean massa.");
        report.setDate(LocalDateTime.now());
        return report;
    }
}  